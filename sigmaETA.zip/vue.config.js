module.exports = {
  runtimeCompiler: true
}
