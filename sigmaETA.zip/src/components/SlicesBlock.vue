<template>
    <div :class="[isFaq == 'yes' ? 'cls-faq-section' : '']">
        <!-- Slice section template -->
        <section v-for="(slice, index) in slices" :key="'slice-' + index">
            <!-- Text slice component -->
            <template v-if="slice.slice_type === 'text'">
                <text-slice :slice="slice"/>
            </template>
            <!-- Quote slice component -->
            <template v-else-if="slice.slice_type === 'quote'">
                <quote-slice :slice="slice"/>
            </template>
            <!-- Full Width Image slice component -->
            <template v-else-if="slice.slice_type === 'full_width_image'">
                <full-width-image :slice="slice"/>
            </template>
            <!-- Image Gallery slice component -->
            <template v-else-if="slice.slice_type === 'image_gallery'">
                <image-gallery :slice="slice" :is-building-page="isBuildingPage" :is-landlords="isLandlords"/>
            </template>
            <!-- Image Highlight slice component -->
            <template v-else-if="slice.slice_type === 'image_highlight'">
                <image-highlight :slice="slice"/>
            </template>
            <!-- CTA slice component -->
            <template v-else-if="slice.slice_type === 'cta'">
                <cta-slice :slice="slice"/>
            </template>
            <template v-else-if="slice.slice_type === 'smaller_cta'">
                <smallCta-slice :slice="slice" :is-faq="isFaq"/>
            </template>
            <!-- Building slice component -->
            <template v-else-if="slice.slice_type === 'building'">
                <building-slice :slice="slice" :is-building-page="isBuildingPage"/>
            </template>
            <!-- Building slice similar homes component -->
            <template v-else-if="slice.slice_type === 'building_cards'">
                <building-slice :slice="slice" :is-building-page="isBuildingPage"/>
            </template>
            <!-- Embend slice component -->
            <template v-else-if="slice.slice_type === 'embed_section'">
                <embed-slice :slice="slice" />
            </template>
            <!-- Section title with icon -->
            <template v-else-if="slice.slice_type === 'section_title'">
                <title-slice :slice="slice"/>
            </template>
            <!-- Section team -->
            <template v-else-if="slice.slice_type === 'team'">
                <team-slice :slice="slice"/>
            </template>
            <!-- FAQ topic team -->
            <template v-else-if="slice.slice_type === 'faq_topic'">
                <topic-slice :slice="slice" :faq-icon="faqIcon"/>
            </template>
            <!-- Bedrooms -->
            <template v-else-if="slice.slice_type === 'rooms'">
                <room-slice :slice="slice" :is-building-page="isBuildingPage"/>
            </template>
            <!-- Maprooms -->
            <template v-else-if="slice.slice_type === 'map'">
                <map-slice :slice="slice" :is-building-page="isBuildingPage"/>
            </template>
            <!-- FullWidthImageSlice -->
            <template v-else-if="slice.slice_type === 'full_width_images'">
                <full-width-images :slice="slice" />
            </template>
             <!-- Section Spacer -->
            <template v-else-if="slice.slice_type === 'spacer'">
                <spacer-slice :slice="slice"/>
            </template>
            <!-- Static Form Slices -->
            <template v-else-if="slice.slice_type === 'form'">
                <form-slice :slice="slice"/>
            </template>
            <template v-else-if="slice.slice_type === 'members'">
                <members-slice :slice="slice"/>
            </template>
            <template v-else-if="slice.slice_type === 'table'">
                <table-slice :slice="slice"/>
            </template>
        </section>
    </div>
</template>

<script>
// Imports for all slices
const TextSlice = () => import("./slices/TextSlice.vue");
const QuoteSlice = () => import("./slices/QuoteSlice.vue");
const FullWidthImage = () => import("./slices/FullWidthImage.vue");
const ImageGallery = () => import("./slices/ImageGallery.vue");
const ImageHighlight = () => import("./slices/ImageHighlight.vue");
const CtaSlice = ()=> import("./slices/CtaSlice.vue");
const SmallCtaSlice = ()=> import("./slices/SmallCtaSlice.vue");
const BuildingSlice = ()=> import("./slices/BuildingSlice.vue");
const EmbedSlice = ()=> import("./slices/EmbedSlice.vue");
const TitleSlice = ()=> import("./slices/TitleSlice.vue");
const TeamSlice = ()=> import("./slices/TeamSlice.vue");
const TopicSlice = ()=> import("./slices/TopicSlice.vue");
const RoomSlice = ()=> import("./slices/BedroomsSlice.vue");
const MapSlice = ()=> import("./slices/MapSlice.vue");
const FullWidthImages = ()=> import("./slices/FullWidthImageSlice.vue");
const SpacerSlice = ()=> import("./slices/SpacerSlice.vue");
const FormSlice = ()=> import("./slices/FormSlice.vue");
const MembersSlice = ()=> import("./slices/MembersSlice.vue");
const TableSlice = ()=> import("./slices/TableSlice.vue");

export default {
  props: ['slices','faqIcon','isFaq', 'isBuildingPage', 'page', 'buildings', 'isLandlords'],
  name: 'slices-block',
  components: {
    TextSlice,
    QuoteSlice,
    FullWidthImage,
    ImageGallery,
    ImageHighlight,
    CtaSlice,
    SmallCtaSlice,
    BuildingSlice,
    EmbedSlice,
    TitleSlice,
    TeamSlice,
    TopicSlice,
    RoomSlice,
    MapSlice,
    FullWidthImages,
    SpacerSlice,
    FormSlice,
    MembersSlice,
    TableSlice
  },
}
</script>
