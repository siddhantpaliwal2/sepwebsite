<template>
    <div class="inner-content-wrapper teams-cms">
        <h3 v-if="slice.primary.team_section != ''"> <prismic-rich-text :field="slice.primary.team_section"/> </h3>
        <prismic-rich-text :field="slice.primary.description" class="sub-title"/>
        <div class="team-outer">
            <div v-for="item in slice.items" :key="item.id" class="team-wrapper">
                <div class="team-image">
                    <prismic-image :field="item.portrait"/>
                </div>
                <div class="team-details">
                    <div class="detail-inner">
                        <prismic-rich-text :field="item.first_and_lastname" class="name"/>
                        <prismic-rich-text :field="item.position" class="position"/>
                        <prismic-rich-text :field="item.bio" class="bio"/>
                        <div class="contact-wrap">
                            <div class="social-left">
                                <prismic-link v-if="item.instagram.url != undefined " :field="item.instagram" class="social-icon"><prismic-image :field="slice.primary.icon_ig"/> </prismic-link>
                                <prismic-link v-if="item.facebook.url != undefined " :field="item.facebook" class="social-icon"><prismic-image :field="slice.primary.icon_fb"/></prismic-link>
                                <prismic-link v-if="item.twitter.url != undefined " :field="item.twitter" class="social-icon"><prismic-image :field="slice.primary.icon_twitter"/></prismic-link>
                            </div>
                            <div class="contact-right">
                                <prismic-link :field="item.button_link1">
                                    <prismic-rich-text :field="item.contact_button" class="contact-button"/>
                                </prismic-link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  props: ['slice'],   
  name: 'team-slice'
}
</script>
<style scoped> 
.team-wrapper {
    display: -ms-flexbox;
    display: -webkit-box;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 15px;
    width: 100%;
}
.teams-cms .team-outer {
    margin-top: 80px;
}
.team-wrapper .team-image ,
.team-wrapper .team-details {
    position: relative;
    width: 50%;
}
.team-wrapper .team-image img {
    height: 100%;
}
.team-wrapper .team-details  {
    background-color: #fff8e5;
    padding: 40px 30px 40px 40px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
.team-wrapper .team-details .detail-inner {
    width: 100%;
}
.team-wrapper .contact-wrap .social-left {
    display: inline-block;
    vertical-align: middle;
}
.team-wrapper .contact-wrap .contact-right {
    display: inline-block;
    vertical-align: middle;
    float: right;
}
.teams-cms {
    position: relative;
    padding-top: 45px;
}
.teams-cms:before {
    content: '';
    position: absolute;
    left: 60px;
    right: auto;
    top: 0;
    background: #ddd;
    width: 25px;
    height: 1px;
}
.team-wrapper .team-details .social-icon {
    margin-right: 20px;
}
.team-wrapper .team-details .name >>> :first-child {
    color: #000;
    margin-bottom: 0;
}
.team-wrapper .team-details .position >>> :first-child {
  color: #3f3d39;
  margin-bottom: 0;
  margin-top: 7px;
}
.team-wrapper .team-details .bio >>> :first-child {
  margin-bottom: 50px;
  margin-top: 25px;
  color: #3f3d39;
  line-height: 20px;
}
.team-wrapper .team-details .contact-button >>> :first-child {
  color: #fff;
  padding: 1px 25px;
  border-radius: 3px;
  text-decoration: none;
  margin: 0;
  background: rgb(114, 191, 68);
  text-transform: uppercase;
}
.teams-cms .sub-title >>> :first-child {
  margin: 0 15px 0 60px;
  color: #222;
  line-height: 32px;
  margin-bottom: 0;
}
@media (max-width: 991px) {
    .teams-cms {
        padding-top: 30px;
    }
    .teams-cms .team-outer {
        margin-top: 60px;
    }
    .teams-cms .sub-title > :first-child {
        font-size: 20px;
    }
}
@media (max-width: 575px) {
    .team-wrapper .team-image ,
    .team-wrapper .team-details {
        width: 100%;
    }
    .teams-cms .team-outer {
        margin-top: 40px;
    }
    .teams-cms .sub-title >>> :first-child {
        font-size: 17px;
    }  
}

@media (max-width: 420px) {
    .team-wrapper .team-details {
        padding: 30px 15px;
    }
}

</style>
