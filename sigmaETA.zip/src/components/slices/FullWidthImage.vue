<template>
  <section class='full-width-image content-section'>
      <div class="full-image-wrap">
        <prismic-image :field="slice.primary.image"/>
      </div>
  </section>
</template>

<script>
export default {
  props: ['slice'],
  name: 'image-caption-slice'
}
</script>
<style scoped>
.full-image-wrap {
    max-width: 325px;
    margin: 0 auto;
    border: 1px solid #ebf2e7;
    padding: 27px 0;
}
.full-width-image.content-section {
  margin-bottom: 25px;
}
@media (max-width: 360px) {
  .full-image-wrap {
    max-width: none;
    margin: 0 15px;
  }
}
</style>