<template>
    <div class="inner-content-wrapper" >
        <div :class="[isFaq == 'yes' ? 'small-cta-outer' : '']" >
            <section class="small-cta" :style="{ background: slice.primary.cta_background_color }">
                <prismic-rich-text :field="slice.primary.cta_text" class="title"/>
                <!-- <prismic-color :field="slice.primary.cta_background_color"/> -->
                <div class="small-cta-button">
                    <prismic-link :field="slice.primary.button_link" :style="{ background: slice.primary.button_color }" >
                        {{ $prismic.richTextAsPlain(slice.primary.button) }}
                    </prismic-link>
                </div>
            </section>
        </div>
    </div>
</template>

<script>
export default {
  props: ['slice', 'isFaq'],   
  name: 'smallCta-slice'
}
</script>



<style scoped> 
.small-cta {
    padding: 30px 60px;
    width: 60%;
}
.small-cta .small-cta-button a {
    background-color: #72bf44;
    color: #fff;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    vertical-align: middle;
    margin-top: 30px;
    max-width: 175px;
    width: 100%;
    text-align: center;
    padding: 15px 10px;
}
.small-cta .title >>> :first-child {
  color: #3f3d39;
  margin-bottom: 0;
}
@media (max-width: 991px) {
    .small-cta {
       width: 70%;
    }
    .small-cta .small-cta-button a {
        padding: 10px 20px;
    }
    .small-cta .title  >>> :first-child {
        font-size: 21px;
    }
}
@media (max-width: 575px) {
    .small-cta {
        padding: 30px;
        width: 100%;
        margin-left: 0;
        margin-right: 0;
    }
    .small-cta .small-cta-button a {
        padding: 8px 15px;
        margin-top: 30px;
        font-size: 16px;
    }
    .small-cta .title >>> :first-child  {
        font-size: 20px;
    }
}
</style>