<template>
    <div class="inner-content-wrapper">
        <div class="main-part">
            <div class="section-main-title" ><prismic-rich-text :field="slice.primary.title" class="cms-title"/></div>
            <div class="room-card">
                <div v-for="(item, item_index) in slice.items" :key="item.id" class="room-wrapper">
                    <div class="room-image">
                        <carousel 
                            :autoplay="true" 
                            :loop="true"
                            :perPage="1"
                            :navigationEnabled="true"
                            :paginationEnabled="true"
                            :speed="2000" 
                            navigationNextLabel="<i class='fa fa-chevron-right'></i>" 
                            navigationPrevLabel="<i class='fa fa-chevron-left'></i>"
                            paginationActiveColor="#72bf44" 
                            :autoplayTimeout="3000">
                            <template v-for="(image, index) in slice.items[item_index].carousel_bedroom" >
                                <slide :key="'carousel_'+index" v-if=" (image.url != undefined) || (image.mobile != undefined)">
                                    <picture class="slider-img">
                                        <img :src="image.url">
                                        <source v-if="image.mobile != undefined" :srcset="image.mobile.url" media="(max-width: 750px)">
                                    </picture>
                                </slide>
                            </template>
                        </carousel>
                        <prismic-rich-text :field="item.overlay" class="overlay"/>
                    </div>
                    <div class="room-detail">
                        <div class="detail-inner">
                            <prismic-rich-text :field="item.room_type" class="type"/>
                            <prismic-rich-text :field="item.description" class="desc"/>
                            <div v-if="item.space != ''" >
                                <prismic-rich-text :field="item.space" class="size"/>
                            </div>
                            <prismic-rich-text :field="item.feature_list" class="feature"/>
                            <div class="btn-wrapper">
                                <prismic-rich-text :field="item.starting_price" class="price"/>
                                <!-- <prismic-link :field="item.button_link" class="request-btn">{{ $prismic.richTextAsPlain(item.button) }}</prismic-link> -->
                                <a href="javascript:void(0)" ref="item.id"  class="request-btn" @click="showModal('wait-list-modal', item.button_link.url, item.room_type[0].text)">{{ $prismic.richTextAsPlain(item.button) }}</a>
                            </div>
                            <prismic-rich-text :field="item.room_available"/>
                        </div>
                        <div>
                        </div>
                    </div>
                </div>
                <b-modal size="xl" centered :hide-footer="true" :hide-header="true" id="wait-list-modal">
                    <div class="d-block text-center">
                        <b-embed
                            type="iframe"
                            :src="waitListLink"
                            allowfullscreen
                        ></b-embed>
                    </div>
                    <b-button class="mt-3 pull-right btn-waitlist" @click="$bvModal.hide('wait-list-modal')">Close</b-button>
                </b-modal>
            </div>
        </div>
    </div>
</template>

<script>
import { Carousel, Slide } from 'vue-carousel';
    export default {
        props: ['slice', 'isBuildingPage'],   
        name: 'room-slice',
        components: {
            Carousel,
            Slide
        },
        data () {
            return {
                waitListLink: '',
                buildingName: this.slice.building_name,
                sliderImages: []
            }
        },
        methods: {
            showModal(modalId, link, roomName) {
                if(typeof(link) !== 'undefined') {
                    if(link.includes('www.casamiacasatua.co')) {
                        //this.waitListLink = 'http://localhost:8080/waitlist-form/' + this.buildingName + '/' + roomName
                        this.waitListLink = link + '/' + this.buildingName + '/' + roomName
                        this.$root.$emit('bv::show::modal', modalId)
                    } else {
                        window.open(link, "_blank");
                    }
                }
            },
            getSliderImages() { 
                //Set slices as variable
                var _this = this;
                _this.slice.items.filter(function(item, index) {
                    var list = [];
                    Object.keys(item).map(function(key) {
                        if(key.includes("picture")) {
                            if(item[key].url != undefined) {
                                list.push(item[key]);
                            }
                        }
                    });
                    _this.slice.items[index].carousel_bedroom = list;
                });
            }
        },
        beforeMount() {
            this.getSliderImages()
        }
    }    
</script>



<style scoped> 
.btn-waitlist {
    color: #fff !important;
    background-color: #72bf44 !important;
    border-color: #72bf44 !important;
}
[id^=wait-list-modal___] {
    z-index: 99999 !important;
}
#modal-header {
    margin: unset !important;
    max-width: unset  !important;
}
.section-main-title .cms-title >>> :first-child {
  color: #222222;
  margin-bottom: 40px;
  text-align: left;
}
.room-wrapper {
    display: -ms-flexbox;
    display: -webkit-box;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 45px;
}
.room-card {
    margin-top: 50px;
}
.room-wrapper .room-image >>> .VueCarousel-navigation-button {
    top: 50%;
    -webkit-transform: translateY(-50%);
    -moz-transform: translateY(-50%); 
    -o-transform: translateY(-50%); 
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    background-color: #72bf44!important;
    height: 50px;
    border-radius: .3125rem;
    box-shadow: 0 2px 6px 0 rgba(0,0,0,.4);
    padding: 0;
}
.room-wrapper .room-image >>> .VueCarousel-navigation-button.VueCarousel-navigation-prev {
    left: 15px;
    right: auto;
}
.room-wrapper .room-image >>> .VueCarousel-navigation-button.VueCarousel-navigation-next {
    right: 15px;
    left: auto;
}
.room-wrapper .room-image >>> .VueCarousel-navigation-button .fa {
   color: rgba(255,255,255,1);
    
}
.room-wrapper .room-image >>> .VueCarousel-navigation-button.VueCarousel-navigation-prev, .room-wrapper .room-image >>> .VueCarousel-navigation-button.VueCarousel-navigation-next { 
	padding: 0px 18px!important;
}
.room-wrapper .room-image >>> .VueCarousel-pagination {
	position: absolute;
    bottom: 15px;
    top: auto;
}
.room-wrapper .room-image ,
.room-wrapper .room-detail {
    width: 50%;
    position: relative;
}
.room-wrapper .room-image img {
    height: 100%;
}
.room-wrapper .room-image .overlay {
    position: absolute;
    bottom: 25px;
    left: 25px;
}
.room-wrapper .room-detail {
    background-color: #fff8e5;
    padding: 35px 20px 35px 35px;
}
.room-wrapper .room-detail .feature {
    margin: 10px 15px;
    width: 100%;
    overflow: hidden;
}
.room-wrapper .room-detail  .btn-wrapper {
    display: -ms-flexbox;
    display: -webkit-box;
    display: flex;
    position: relative;
}
.room-wrapper .room-detail  .btn-wrapper .request-btn {
    color: #fff;
    font-size: 17px;
    background-color: #72bf44;
    font-weight: 500;
    padding: 5px 10px;
    border-radius: 5px;
    text-decoration: none;
    position: absolute;
    right: 0;
    top: 0;
    bottom: auto;
}
.room-wrapper .room-detail {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
}
.room-wrapper .room-detail  .detail-inner {
    width: 100%;
}
/* bedroom */
.room-wrapper .room-detail .type >>> :first-child {
  color: #000000;
  /* font-weight: 600; */
  line-height: normal;
  margin-bottom: 0;
}
.room-wrapper .room-detail .desc >>> :first-child,
.room-wrapper .room-detail .size >>> :first-child {
  margin-top: 7px;
}
.room-wrapper .room-detail .feature >>> ul {
  list-style: none;
  padding: 0;
  margin-bottom: 0;
}
.room-wrapper .room-detail .desc >>> p ,
.room-wrapper .room-detail .feature >>> ul li ,
.room-wrapper .room-detail .size >>> p {
  /* font-size: 13px; */
  color: #000;
  line-height: normal;
  margin-bottom: 0;
}
.room-wrapper .room-detail .feature >>> p ,
.room-wrapper .room-detail .feature >>> ul li {
  position: relative;
  padding-left: 15px;
  color: #000;
  margin-bottom: 0;
  width: 50%;
  float: left;
  line-height: 18px;
}
.room-wrapper .room-detail .feature >>> p:after ,
.room-wrapper .room-detail .feature >>> ul li:after {
  content: '';
  position: absolute;
  top: 50%;
  -webkit-transform: translateY(-50%);
  -moz-transform: translateY(-50%); 
  -o-transform: translateY(-50%); 
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
  left: 0;
  height: 7px;
  width: 7px;
  background-color: #72bf44;
  border-radius: 50%;
}
.room-wrapper .room-detail .price >>> :first-child {
  color: #000;
  margin-bottom: 0;
}
.room-wrapper .room-image .overlay >>> :first-child {
  background-color: #f1eaef;
  border: 1px solid #ef5357;
  color: #000;
  padding: 0 10px;
  margin-bottom: 0;
  display: inline-block;
  vertical-align: middle;
}

@media (max-width: 991px) {
    .room-wrapper .room-detail .btn-wrapper {
        display: block;
    }
    .room-wrapper .room-detail .btn-wrapper .request-btn {  
        position: relative;
        margin-top: 10px;
        display: inline-block;
        vertical-align: middle;
    }
    .room-wrapper .room-image ,
    .room-wrapper .room-detail {
        width: 100%;
    }
}
@media (max-width: 767px) { 
    .VueCarousel-navigation-button.VueCarousel-navigation-next, .VueCarousel-navigation-button.VueCarousel-navigation-prev {
        display: none;
    }
}
@media (max-width: 767px) and (min-width: 576px) {
  .room-wrapper .room-detail .feature >>> p ,
  .room-wrapper .room-detail .feature >>> ul li {
      width: 100%;
  }
    .room-wrapper .room-image img {
		height: auto;
	}
}
@media (max-width: 575px) {
    .room-wrapper .room-image ,
    .room-wrapper .room-detail {
        width: 100%;
    }  
    .room-wrapper .room-image img {
		height: auto;
	}
    .section-main-title .cms-title >>> :first-child {
        font-size: 18px;
    }
    .room-wrapper .room-detail .btn-wrapper .request-btn {  
        position: relative;
        margin-top: 10px;
        display: inline-block;
        width: 100%;
        text-align: center;
        padding: 15px 0px;
        font-size: 20px;
        vertical-align: middle;
    }
}
@media (max-width: 420px) {
    .room-wrapper .room-detail {
        padding: 30px 15px;
    }
    .room-wrapper .room-detail .feature >>> p ,
    .room-wrapper .room-detail .feature >>> ul li {
        width: 100%;
    }
}



</style>
