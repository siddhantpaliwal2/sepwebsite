<template>
    <div :class="[isBuildingPage == 'Yes' ? 'main-part building-cms build-page inner-content-wrapper' : 'main-part building-cms']">
        <div :class="[isBuildingPage == 'Yes' ? 'left-content ' : 'col-lg-6 col-md-6 col-sm-12 left-content']">
            <div v-if="isBuildingPage == 'Yes'" class="left-wrapper" ref="map-block">
                <template v-if="similerBuildings.length > 0" >
                    <h2 class="section-main-title" v-if="slice.primary.feature_title != '' && sliceType == 'building'"><prismic-rich-text :field="slice.primary.feature_title" class="cms-title"/> </h2>
                    <h2 class="section-main-title" v-if="slice.primary.title != '' && sliceType == 'building_cards'"><prismic-rich-text :field="slice.primary.title" class="cms-title"/> </h2>
                    <button v-show="(showToggleButton && isDisplayMode)" class="btn sticky-toggle-map-button mb-5" @click="showMapOrList()">
                        <span v-show="isMap">{{ $prismic.richTextAsPlain(slice.primary.list_button) }}</span>
                        <span v-show="isList">{{ $prismic.richTextAsPlain(slice.primary.map_button) }}</span>
                    </button>
                    <button v-show="showToggleButton"  id="sticky-map-button"  class="btn toggle-map-button mb-5" @click="showMapOrList()">
                        <span v-show="isMap">{{ $prismic.richTextAsPlain(slice.primary.list_button) }}</span>
                        <span v-show="isList">{{ $prismic.richTextAsPlain(slice.primary.map_button) }}</span>
                    </button>
                    <div :class="[isList ? '' : 'map-hide'] + ' building-card row'">
                        <div v-for="item in similerBuildings" :key="item.id" class="card-main">
                            <div class="content-wrap">
                                <router-link :to="linkResolver(item)" class="card-link">
                                    <prismic-image v-if="(item.data.heroimageslider[0] != undefined)" :field="item.data.heroimageslider[0].heroimage.card"/>
                                    <div class="name"> {{ $prismic.richTextAsPlain(item.data.building_name) }} </div>
                                    <div class="title"> {{item.data.neighbourhood_name}} </div>
                                    <prismic-rich-text :field="item.data.building_address" class="address"/>
                                    <prismic-rich-text :field="item.data.short_building_description" class="desc"/>
                                    <div class="building-bottom-content">
                                        <prismic-rich-text :field="item.data.starting_price" class="price"/>
                                        <template v-if="item.data.overlay[0] != undefined && item.data.overlay[0].text != ''">
                                            <prismic-rich-text :field="item.data.overlay" class="room-available-today"/>
                                        </template>
                                    </div>
                                </router-link>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
             <div v-else class="left-wrapper" ref="map-block">
                <h2 class="section-main-title" v-if="slice.primary.feature_title != '' && sliceType == 'building'"><prismic-rich-text :field="slice.primary.feature_title" class="cms-title"/> </h2>
                <h2 class="section-main-title" v-if="slice.primary.title != '' && sliceType == 'building_cards'"><prismic-rich-text :field="slice.primary.title" class="cms-title"/> </h2>
                <button v-show="(showToggleButton && isDisplayMode)" class="btn sticky-toggle-map-button mb-5" @click="showMapOrList()">
                    <span v-show="isMap">{{ $prismic.richTextAsPlain(slice.primary.list_button) }}</span>
                    <span v-show="isList">{{ $prismic.richTextAsPlain(slice.primary.map_button) }}</span>
                </button>
                <button v-show="showToggleButton"  id="sticky-map-button"  class="btn toggle-map-button mb-5" @click="showMapOrList()">
                    <span v-show="isMap">{{ $prismic.richTextAsPlain(slice.primary.list_button) }}</span>
                    <span v-show="isList">{{ $prismic.richTextAsPlain(slice.primary.map_button) }}</span>
                </button>
                <div :class="[isList ? '' : 'map-hide'] + ' building-card row'">
                    <div v-for="item in buildings" :key="item.id" class="card-main">
                         <div class="content-wrap">
                            <router-link :to="linkResolver(item)" class="card-link">
                                <prismic-image v-if="(item.data.heroimageslider[0] != undefined)" :field="item.data.heroimageslider[0].heroimage.card"/>
                                <div class="name"> {{ $prismic.richTextAsPlain(item.data.building_name) }} </div>
                                <div class="title"> {{item.data.neighbourhood_name}} </div>
                                <prismic-rich-text :field="item.data.building_address" class="address"/>
                                <prismic-rich-text :field="item.data.short_building_description" class="desc"/>
                                <div class="building-bottom-content">
                                    <prismic-rich-text :field="item.data.starting_price" class="price"/>
                                     <template v-if="item.data.overlay[0] != undefined && item.data.overlay[0].text != ''">
                                       <prismic-rich-text :field="item.data.overlay" class="room-available-today"/>
                                    </template>
                                </div>
                            </router-link>
                         </div>
                    </div>
                </div>
            </div>
        </div>
        <div v-if="isBuildingPage != 'Yes'" :class="[isMap ? '' : 'map-hide'] + ' map-outer'">
            <div class="google-map" :id="mapName"></div>
        </div>
    </div>
</template>

<script>
import mapJson from '../../../custom_types/GoogleMap.json'
function elementInViewport(el) {
    if(el != null) {
        var top = el.offsetTop;
        var height = el.offsetHeight;

        while(el.offsetParent) {
            el = el.offsetParent;
            top += el.offsetTop;
        }

        return (
            top >= window.pageYOffset &&
            (top + height) <= (window.pageYOffset + window.innerHeight)
        );
    }
}
export default {
    props: ['slice', 'isBuildingPage'],
    name: 'building-cards',
    data () {
        return {
            buildings: [],
            similerBuildings: [],
            linkResolver: this.$prismic.linkResolver,
            mapName: "location-multi-map",
            markerCoordinates: [],
            map: null,
            bounds: null,
            markerIcon: (this.slice.slice_type == 'building') ? this.slice.primary.marker.url : '',
            mapStyleJson: mapJson,
            markers: [],
            isMap: false,
            isList: true,
            showToggleButton: false,
            toggleMapButton: 'Map',
            currentWidth: '',
            sliceType: this.slice.slice_type,
            isDisplayMode: true,
        }
    },
    methods: {
        showMapOrList() {
            this.isMap = !this.isMap
            this.isList = !this.isList
            if(this.isMap) {
                this.toggleMapButton = 'List'
                this.setZoom();
            } else {
                this.toggleMapButton = 'Map'
            }
            this.scrollToMap('map-block')
        },
        getBuildings () {
            this.$prismic.client.query(
                this.$prismic.Predicates.at('document.type', 'explore_building') // ,this.$prismic.Predicates.any('my.explore_building.city', ['Singapore'])
            ).then((response) => {
                this.buildings = response.results;
                if(this.sliceType == 'building') {
                    this.setCoordinates(this.buildings)
                }
                if(this.sliceType == 'building_cards') {
                    this.setSimilarBuildings(this.buildings)
                }
            })
        },
        setSimilarBuildings(buildings) {
            let neighbourhood = '';
            this.$prismic.client.getByUID('explore_building', this.$route.params.uid).then(function(document) {
                neighbourhood = document.data.neighbourhood_name
            });

            for (let item of buildings) {
                if(this.$route.params.uid.trim() != item.uid.trim()) {
                    this.$prismic.client.getByUID(
                        'explore_building', item.uid.trim()
                    ).then((response) => {
                        if(neighbourhood == response.data.neighbourhood_name && response.data.overlay[0].text != '') {
                            this.similerBuildings.push(item)
                        }
                    });
                }
            }
        },
        setCoordinates(buildings) {
            buildings = JSON.parse(JSON.stringify(buildings))
            for (let item of buildings) {
                let link = this.linkResolver(item)
                this.markerCoordinates.push({
                    latitude: item.data.map.latitude,
                    longitude: item.data.map.longitude,
                    name: item.data.building_name[0].text,
                    link: link,

                })
            }
            this.bounds = new google.maps.LatLngBounds();
            const element = document.getElementById(this.mapName)
            const mapCentre = this.markerCoordinates[0]
            const options = {
                center: new google.maps.LatLng(mapCentre.latitude, mapCentre.longitude),
                fullscreenControl: false
            }
            this.map = new google.maps.Map(element, options);

            var styledMapType = new google.maps.StyledMapType(this.mapStyleJson, {name: 'Styled Map'});
            this.map.mapTypes.set('styled_map', styledMapType);
            this.map.setMapTypeId('styled_map');
            var infowindow = new google.maps.InfoWindow();
            this.markerCoordinates.forEach((coord) => {
                if (typeof coord.latitude != 'undefined' && typeof coord.longitude != 'undefined') {
                    const position = new google.maps.LatLng(coord.latitude, coord.longitude);
                    const marker = new google.maps.Marker({
                        position,
                        map: this.map,
                        animation: google.maps.Animation.DROP,
                        url: coord.link,
                        icon: this.markerIcon
                    });
                    marker.addListener('mouseover', function() {
                        infowindow.setContent(coord.name);
                        infowindow.open(this.map, marker);
                    });
                    marker.addListener('mouseout', function() {
                        infowindow.close(this.map, marker);
                    });
                    marker.addListener('click', function() {
                        if (marker.getAnimation() !== null) {
                            marker.setAnimation(null);
                        } else {
                            marker.setAnimation(google.maps.Animation.BOUNCE);
                        }
                        window.location.href = marker.url;
                    });
                    this.markers.push(marker)
                    this.map.fitBounds(this.bounds.extend(position))

                }
            });
        },
        handleResize() {
            if(this.currentWidth != window.innerWidth) {
                if(window.innerWidth < 768) {
                    if(this.isMap == true && this.isList == true) {
                        this.getBuildings()
                        this.isList = false
                        this.showMapOrList()
                    }
                    this.showToggleButton = true;
                } else {
                    this.isMap = true;
                    this.isList = true;
                    this.showToggleButton = false;
                }
                this.setZoom()
                this.currentWidth = window.innerWidth;
            }
        },
        setZoom() {
            if(window.innerWidth < 768) {
                if(this.map != null) {
                    this.map.setZoom(12);
                }
            } else {
                if(this.map != null) {
                    this.map.setZoom(14);
                }
            }
        },
        handleScroll() {
            const el = document.getElementById('sticky-map-button');
            if(elementInViewport(el)) {
                console.log();
                this.isDisplayMode = false;
            } else {
                this.isDisplayMode = true;
            }
        },
        scrollToMap(refName) {
            var element = this.$refs[refName];
            element.scrollIntoView({ behavior: 'smooth' });
        }
    },
    created () {
        this.getBuildings()
        if(this.sliceType == 'building') {
            window.addEventListener('resize', this.handleResize)
            document.addEventListener('scroll', this.handleScroll)
            //this.handleScroll()
        }
    },
    beforeMount () {
        if(this.sliceType == 'building') {
            this.handleResize();
        }
    },
    destroyed() {
        if(this.sliceType == 'building') {
            document.removeEventListener('scroll', this.handleScroll);
        }
    },
}
</script>

<style scoped>
.toggle-map-button {
    min-width: 225px;
    color: #fff;
    background-color: #f55e61;
    border-color: #f55e61;
}
.sticky-toggle-map-button {
    min-width: 225px;
    color: #fff;
    background-color: #f55e61;
    border-color: #f55e61;
}
.map-hide {
    display: none;
}
.section-main-title .cms-title >>> :first-child {
    color: #222222;
    margin-bottom: 40px;
    text-align: left;
}
.building-cms {
    text-align: center;
    position: relative;
}
.building-cms .building-card .name   {
    font-size: 18px;
    color: #000;
    font-weight: 600;
    text-transform: capitalize;
    text-decoration: none;
    margin: 5px 0;
    display: block;
}
.building-cms  .left-content {
    position: relative;
    background-color: #fff;
    z-index: 9;
}
.building-cms .building-card .title >>> :first-child ,
.building-cms .building-card .desc >>> :first-child ,
.building-cms .building-card .price >>> :first-child ,
.building-cms .building-card .address >>> :first-child {
    color: #000;
    margin-bottom: 0;
    line-height: normal;
}
.building-cms .building-card .price >>> :first-child,
.building-cms .building-card .title >>> :first-child {
    margin-top: 6px;
}
.building-cms .building-card .desc >>> :first-child {
    margin-top: 20px;
}
.building-cms .building-card .room-available-today >>> :first-child {
    background-color: #feefef;
    border: 1px solid #ef5357;
    color: #000;
    font-size: 12px;
    font-weight: 600;
    padding: 0 4px;
    margin-bottom: 0;
    display: inline-block;
    vertical-align: middle;
}
.building-card .card-main {
    position: relative;
    margin-bottom: 65px;
}
.building-card .card-main .building-bottom-content .room-available-today {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
}
.building-bottom-content .price >>> p {
    font-weight: bold;
}
.building-card .card-main .building-bottom-content .price {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 30px;
}
.building-cms .building-card .content-wrap {
    margin-bottom: 50px!important;
}
.building-card .card-main .card-link {
    display: block;
}
@media (max-width: 767px) {
    .building-cms .building-card .col-lg-6.col-md-12 {
        flex: 0 0 50%;
        max-width: 50%;
    }
    .building-card  {
        padding-right: 0;
        margin-left: 0;
        margin-right: 0;
    }
    .build-page .building-card {
        padding-top: 0;
    }
    .sticky-toggle-map-button {
        min-width: inherit;
        display: block;
        width: 100%;
        position: fixed;
        top: 90px;
        left: 0;
        right: 0;
        border-radius: 0;
        z-index: 2;
    }
    .sticky-toggle-map-button.btn.focus, .sticky-toggle-map-button.btn:focus {
        box-shadow: none;
    }
}
@media (max-width: 575px) {
    .building-cms .building-card .col-lg-6.col-md-12 {
        flex: 0 0 100%;
        max-width: 100%;
    }
    .section-main-title .cms-title >>> :first-child {
        font-size: 18px;
    }
}
</style>
