<template>
    <div>
        <template v-if="slice.slice_label == 'getintouch'">        
            <getin-touch-form />
        </template>
        <template v-else-if="slice.slice_label == 'corporate'">
            <corporate-form />
        </template>
        <template v-else-if="slice.slice_label == 'landlords'">
            <land-lord-form />
        </template>
        <template v-else-if="slice.slice_label == 'findyourhome'">
            <finda-home-form />
        </template>
        <template v-else-if="slice.slice_label == 'newcity'">
            <melbourne-form />
        </template>
    </div>
</template>

<script>
const MelbourneForm = () => import("../forms/MelbourneForm.vue");
const CorporateForm = () => import("../forms/CorporateForm.vue");
const GetinTouchForm = () => import("../forms/GetinTouchForm.vue");
const LandLordForm = () => import("../forms/LandLordForm.vue");
const FindaHomeForm = () => import("../forms/FindaHomeForm.vue");
export default {
  props: ['slice'],
  name: 'form-slice',
  components: {
    MelbourneForm,
    CorporateForm,
    GetinTouchForm,
    LandLordForm,
    FindaHomeForm
  }
}
</script>

<style>
</style>
