<template>
    <div class="cta-wrapper" id="cta-section">
    <section class="cta">
        <prismic-rich-text :field="slice.primary.cta_text" class="text"/>
        <!-- <prismic-color :field="slice.primary.cta_background_color"/> -->
        <div class="cta-button" v-if="slice.primary.cta_button[0].text != ''">
            <prismic-link :field="slice.primary.cta_button_link">
                {{ $prismic.richTextAsPlain(slice.primary.cta_button) }}
            </prismic-link>
            <!-- <prismic-color :field="slice.primary.cta_button_color"/> -->
        </div>
        <div v-show="(slice.primary.cta_button[0].text != '' && isDisplayMode)" class="cta-button cta-mobile-button">
            <prismic-link :field="slice.primary.cta_button_link">
                {{ $prismic.richTextAsPlain(slice.primary.cta_button) }}
            </prismic-link>
            <!-- <prismic-color :field="slice.primary.cta_button_color"/> -->
        </div>
    </section>
    </div>
</template>

<script>
function elementInViewport(el) {
    if(el != null) {
        var top = el.offsetTop;
        var height = el.offsetHeight;

        while(el.offsetParent) {
            el = el.offsetParent;
            top += el.offsetTop;
        }

        return (
            top >= window.pageYOffset &&
            (top + height) <= (window.pageYOffset + window.innerHeight)
        );
    }
}
export default {
  props: ['slice'],   
  name: 'cta-slice',
  data () {
        return {
            isDisplayMode: true
        }
    },
    created() {
        document.addEventListener('scroll', this.handleScroll);
        this.handleScroll()
    },
    destroyed() {
        document.removeEventListener('scroll', this.handleScroll);
    },
    methods: {
        handleScroll() {
            const el1 = document.getElementById('cta-section');
            const el2 = document.getElementById('hero-join-us-today');
            if(elementInViewport(el1)) {
                this.isDisplayMode = false;
            } else {
                if(elementInViewport(el2)) { 
                    this.isDisplayMode = false;
                } else {
                    this.isDisplayMode = true;
                }
            }
        }
    }
}
</script>

<style scoped> 
.cta {
    width: 100%;
    min-height: 8em;
    background-color: #72BF44;
    text-align: center;
    color: white;
    font-size: 1.3rem;
    font-weight: bold;
    padding: 90px 15px;
}
.cta-button a {
    color: #72bf44;
    background-color: #fff;
    padding: 15px 30px;
    border-radius: 5px;
    text-decoration: none;
    margin-top: 65px;
    display: inline-block;
    vertical-align: middle;
    font-size: 26px;
    font-weight: bold;
}
.cta-wrapper {
    position: relative;
    background-color: #fff;
    width: 100%;
    overflow: hidden;
    /* z-index: 8; */
}
.cta .text >>> :first-child {
  margin-bottom: 0;
  font-size: 48px;
  font-weight: bold;
  line-height: normal;
}
@media (max-width: 1299px) {
  .cta .text >>> :first-child {
    font-size: 28px;
  }
}
@media (max-width: 991px) {
    .cta {
        padding: 70px 15px;
    }
    .cta-button a {
        padding: 10px 20px;
        margin-top: 40px;
        font-size: 20px;
    }
}
@media (max-width: 767px) { 
    .cta .cta-mobile-button {
        position: fixed;
        bottom: 0;
        left: 0;
        background-color: #72bf44; 
        width: 100%;
        right: 0;
        opacity: 1;
        z-index: 9999;
        box-sizing: border-box;
    }
    .cta .cta-mobile-button a {
        font-size: 24px;
        display: block;
        background-color: #72bf44;
        color: #fff;
        font-weight: normal;
        margin-top: 0;
        border-radius: 0;
    }
}
@supports (-webkit-overflow-scrolling: touch) {
    .cta .cta-mobile-button {
        position: fixed;
        bottom: 0;
        left: 0;
        background-color: #72bf44; 
        width: 100%;
        right: 0;
        opacity: 1;
        z-index: 9999;
        box-sizing: border-box;
    }
}
@media (min-width: 768px) { 
    .cta .cta-mobile-button {
        display: none;
    }
}
@media (max-width: 575px) {
    .cta {
        padding: 40px 15px;
    }
    
    .cta .text >>> :first-child {
        font-size: 20px;
    }
    .cta {
        min-height: inherit;
    }   
}
</style>