<template>
  <div class="topic">
    <section class="inner-content-wrapper">
      <h2><prismic-rich-text :field="slice.primary.title" class="topic-heading"/></h2>
      <div class="gallery ">
          <div v-for="item in sliceItems" :key="item.id" class="gallery-item">
              <div class="topic-left">
              <prismic-image :field="faqIcon"/>
              </div>
              <div class="topic-right">
              <prismic-rich-text :field="item.question" class="topic-title"/>
              <prismic-rich-text :field="item.answer" class="topic-desc"/>
              <prismic-link :field="item.link" class="gallery-link">{{ $prismic.richTextAsPlain(item.link_label) }}</prismic-link>
              </div>
          </div>
          <div v-if="slice.items.length > 2" v-show="isShowMore" @click="showMore()" class="show-more-link">
            <i class="fa fa-bars" aria-hidden="true"></i>
            Show more
          </div>
          <div v-if="slice.items.length > 2" v-show="!isShowMore" @click="showLess()" class="show-less-link">
            <i class="fa fa-arrow-up" aria-hidden="true"></i>
            Show less
          </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
props: ['slice', 'faqIcon'],
name: 'topic-slice',
data() {
return {
isShowMore: true,
sliceItems: []
}
},
methods: {
showMore() { 
this.sliceItems = this.slice.items
this.isShowMore = false
},
showLess() { 
this.sliceItems = this.slice.items.slice(0, 2)
this.isShowMore = true
}
},
beforeMount() {
this.sliceItems = this.slice.items.slice(0, 2)
}
}
</script>


<style scoped>
.topic {
  padding: 50px 0;
}
.topic .gallery .gallery-item {
  margin-bottom: 25px;
  width: 70%;
}
.topic .gallery .gallery-item .topic-left {
  float: left;
}
.topic .gallery .gallery-item .topic-right {
  overflow: hidden;
  padding-left: 15px;
}
.topic .gallery {
  padding: 0 5px;
}
.topic .show-more-link ,
.topic .show-less-link {
  font-size: 14px;
  color: #f06161;
  font-weight: 500;
  line-height: normal;
  cursor: pointer;
}
.topic .show-more-link i,
.topic .show-less-link i {
  margin: 0 12px 0 5px;
  font-size: 14px;
}
.topic .topic-heading >>> :first-child {
  color: #222;
  margin-bottom: 30px;
}
.topic .gallery-item .topic-title >>> :first-child {
  color: #222;
  margin-bottom: 0;
}
.topic .gallery-item .topic-desc >>> :first-child {
  line-height: 20px;
  color: #222;
  letter-spacing: 0.3px;
  margin-bottom: 0;
  margin-top: 6px;
}
.cls-faq-section section:nth-child(even) > .topic{
  background-color: #fff8e5;
}
@media (max-width: 991px) {
  .topic .gallery .gallery-item {
    width: 100%;
  }
}
@media (max-width: 575px) {
  .topic .topic-heading >>> :first-child {
    font-size: 20px;
  }
}

</style>
