<template>
    <section class="testimonial-section">
        <div class="inner-content-wrapper text-slice-cms">
            <div class="description"><h3><prismic-rich-text :field="slice.primary.title" /></h3></div>
            <carousel :per-page="1" :autoplay="true" :loop="true" :paginationEnabled="false" :autoplayTimeout=20000 :mouse-drag="false">
                <slide v-for="item in slice.items" :key="item.id">
                    <div class="testimonial-content-wrap">
                        <div class="members_pic">
                            <prismic-image :field="item.members_pic"/>
                        </div>
                        <div class="testimonial-content">
                            <div class="testimonial">
                                <prismic-rich-text :field="item.testimonial" />
                            </div>
                            <div class="name_and_title">
                                <prismic-rich-text :field="item.name_and_title" />
                            </div>
                        </div>
                    </div>
                </slide>
            </carousel>
        </div>
    </section>
</template>

<script>
import { Carousel, Slide } from 'vue-carousel';
export default {
  props: ['slice'],   
  name: 'members-slice',
  components: {
    Carousel,
    Slide
  },
  created() {
      console.log('data: ', this.slice)
  }
}
</script>

<style> 
.testimonial-section {
    background-color: #fff7e5;
    padding: 50px 0px;
}
.testimonial-section .description {
    padding-bottom: 40px;
}
.testimonial-section .testimonial p {
    font-size: 16px;
    line-height: 32px;
    margin: 0;
    font-style: italic;
}
.testimonial-section .name_and_title {
    padding-top: 20px;
}
.testimonial-section .name_and_title p {
    font-weight: bold;
    font-size: 16px;
    text-align: right;
}
.testimonial-section .testimonial-content-wrap {
    display: flex;
}
.testimonial-section .members_pic {
    width: 200px;
}
.testimonial-section .testimonial-content {
    width: calc(100% - 200px);
    padding-left: 70px;
}
.testimonial-section .members_pic img {
    border-radius: 50%;
}
@media (max-width: 767px) {
    .testimonial-section .testimonial-content-wrap {
        display: block;
    }
    .testimonial-section .members_pic {
        text-align: center;
        width: 100%;
    }
    .testimonial-section .testimonial-content {
        width: 100%;
        padding-left: 0px;
        text-align: center;
    }
    .testimonial-section .members_pic img{
        width: 150px;
    }
    .testimonial-section .testimonial p {
        text-align: center;
    }
    .testimonial-section .name_and_title p {
        text-align: center;
    }
}
</style>