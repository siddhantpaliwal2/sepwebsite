<template>
    <div class="fullwidth_image_cms">
        <div class="image-block">
            <template v-for="(item, index) in slice.items" >
            <div v-bind:key="index" class="img">
                <prismic-image :field="item.image.horizontal"/>
            </div>
            </template>
        </div>
    </div>
</template>

<script>
export default {
  props: ['slice'],
  name: 'full-width-images'
}
</script>

<style>
.fullwidth_image_cms .image-block {
    position: relative ;
    z-index: 7;
}
.fullwidth_image_cms .image-block .img:nth-child(1) {
    position: absolute;
    left: 0;
    padding-top: 190px;
    width: 62%;
}
.fullwidth_image_cms .image-block .img:nth-child(2) {
    position: absolute;
    right: 0;
    width: 58%;
}
.fullwidth_image_cms .image-block .img:nth-child(3) {
    width: 53%;
    margin: 0 0 0 auto;
    z-index: 33;
    top: 0;
    bottom: 0;
    right: 0;
    position: relative;
    padding-top: 470px;
    padding-left: 80px;
    padding-right: 80px;
    text-align: center;
}

@media(min-width:1800px) {
    .fullwidth_image_cms .image-block .img:nth-child(1) {     
        width: 57%;
        text-align: right;
    }
    .fullwidth_image_cms .image-block .img:nth-child(1) img {
        height: 600px;
    }
    .fullwidth_image_cms .image-block .img:nth-child(2) {  
        width: 55%;
    }
    .fullwidth_image_cms .image-block .img:nth-child(2) img {
        height: 560px;
    }
    .fullwidth_image_cms .image-block .img:nth-child(3) {
        padding-left: 50px;
        padding-right: 50px;
        text-align: left;        
    }
    .fullwidth_image_cms .image-block .img:nth-child(3) img {
        height: 740px;
    }
}
@media(max-width:1299px) {
    .fullwidth_image_cms .image-block .img:nth-child(1) {
        padding-top: 150px;
    }
    .fullwidth_image_cms .image-block .img:nth-child(2) {
        width: 55%;
    }
    .fullwidth_image_cms .image-block .img:nth-child(3) {
        padding-top: 350px;
    }
}
@media(max-width:1024px) {
    .fullwidth_image_cms .image-block .img:nth-child(3) {
        padding-top: 295px;
    }
}
@media (max-width: 991px) {
    .fullwidth_image_cms .image-block .img:nth-child(3) {
        padding-left: 50px;
        padding-right: 50px;
        padding-top: 230px;
    }   
}
@media (max-width: 767px) {
    .fullwidth_image_cms .image-block .img:nth-child(3) {
        padding-left: 30px;
        padding-right: 30px;
        padding-top: 185px;
    }   
}
@media (max-width: 575px) {
    .fullwidth_image_cms .image-block .img:nth-child(3) {
        padding-left: 30px;
        padding-right: 15px;
        padding-top: 120px;
    }   
    .fullwidth_image_cms .image-block .img:nth-child(1) {
        padding-top: 50px;
    }
}
@media (max-width: 375px) {
    .fullwidth_image_cms .image-block .img:nth-child(3) {
        padding-top: 90px;
    }   
}
</style>
