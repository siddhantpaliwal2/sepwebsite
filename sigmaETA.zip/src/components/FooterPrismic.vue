<template>
  <footer class="footer">
    <div class="footer-inner">
      <div class="row">
        <div class="col-sm-12">
          <span class="title">sigma eta pi</span>
        </div>
        <div class="col-sm-12">
          <span class="email">info@mysite.com</span>
        </div>
        <div class="col-sm-12">
          <span class="poweredby">©2022 by sigma eta pi.</span>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'FooterPrismic',
  data () {
    return {
    };
  }
}
</script>
<style>

.footer {
  padding: 60px 0;
  margin: 0 auto;
  text-align: center;
  max-width: none;
  padding-bottom: 0;
  position: relative;
  background-color: #2f2e2e;
  color:#fff
}
.footer-detail {
  margin: 15px 20px;
}
</style>
