<template>
  <header class="site-header">
    <div class="row">
      <div class="col-lg-2 col-md-3 col-sm-4 header-logo">
        <router-link to="/" class="logo">
          SIGMA ETA PI
        </router-link>
      </div>
      <div class="col-lg-10 col-md-9 col-sm-8 header-menu">
        <nav class="navbar navbar-expand-lg">
            <div id="navbarmenuContent" class="collapse navbar-collapse">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item dropdown">
                  <router-link to="/page/about" class="menu-maintitle nav-link">Home</router-link>
                </li>
                <li class="nav-item dropdown">
                  <router-link to="#" data-toggle="dropdown" class="menu-maintitle nav-link ">Brothers</router-link>
                    <div aria-labelledby="navbarDropdown" class="dropdown-menu">
                      <router-link to="/executives" class="menu-subtitle dropdown-item">Executive</router-link>
                      <router-link to="/actives" class="menu-subtitle dropdown-item">Actives</router-link>
                    </div>
                </li>
                <li class="nav-item dropdown">
                  <router-link to="/bruintank" class="menu-maintitle nav-link">Bruin Tank</router-link>
                </li>
                <li class="nav-item dropdown">
                  <router-link to="/recruitment" class="menu-maintitle nav-link">Recruitment</router-link>
                </li>
              </ul>
            </div>
        </nav>
      </div>
    </div>
  </header>
</template>



<script>
export default {
  name: 'Header',
  data () {
    return {
    }
  },
};


</script>


<style>

/* Site header */
.site-header .logo {
  font-size: 22px;
  font-weight: 900;
  line-height: 20px;
}
.site-header nav {
  float: left;
}
.site-header nav ul {
  margin: 0;
}
.site-header nav li {
  margin-left: 27px;
}

/* Media Queries */
/* insys*/
.site-header {
  position: fixed;
  left: 0;
  right: 0;
  background-color: rgba(255,255,255,0.9);
  padding: 10px 15px;
  border: 1px solid #f2f2f2;
  height: 80px;
  z-index: 9999;
  width: 100%;
  top: 10px;
}
.site-header .header-menu ul li {
  display: inline-block;
  vertical-align: middle;
}
.site-header .row {
    -ms-flex-align: center;
    -webkit-box-align: center;
    align-items: center;
}
/* header menu */
.site-header .header-menu ul li .menu-maintitle {
  font-size: 14px;
  color: #222;
  font-weight: normal;
  padding: 0px 8px;
  position: relative;
  cursor: pointer;
  display: inline-block;
  vertical-align: middle;
}
.site-header .header-menu .get-touch-btn {
  font-size: 14px;
  border: 2px solid #f55e61;
  padding: 0px 15px;
  border-radius: 5px;
  color: #f55e61;
  font-weight: 600;
  letter-spacing: 0;
  line-height: 38px;
  height: 40px;
  margin-left: 27px;
}
.site-header .header-menu a {
  text-decoration: none;
}
.site-header  .header-menu .get-touch-btn:hover {
  border-color: #72bf44;
  color: #fff;
  background-color: #72bf44;
}
.header-menu{
  display: flex;
  align-items: center;
}
.site-header .header-menu  .navbar-expand-lg .navbar-nav .dropdown-menu .menu-subtitle {
  color: #666;
  padding: 0 15px;
}
.site-header .header-menu .dropdown-toggle::after {
  border-top: .4em solid #72bf44;
  display: none;
}
.site-header nav {
  padding: 0;
}

.site-header .header-menu .navbar-expand-lg .navbar-nav .dropdown-menu .menu-subtitle:hover,
.site-header .header-menu .navbar-expand-lg .navbar-nav .menu-subtitle.dropdown-item:focus,
.site-header .header-menu .navbar-expand-lg .navbar-nav .menu-subtitle.dropdown-item:hover {
  background-color: #72bf44;
  color: #222;
}
.site-header .header-menu ul li i {
  color: #72bf44;
  font-size: 16px;
  cursor: pointer;
}
.site-header nav li:first-child {
  margin-left: 0;
}
</style>
