<template>
  <section class="FAQs">
    <header-prismic/>
    <!-- Button to edit document in dashboard -->
    <!-- <prismic-edit-button :documentId="documentId"/> -->
    <section class="banner slider-cms">
      <div class="slider-outer">
        Recruitment
     </div>
    </section>
     <footer-prismic/>
  </section>
</template>

<script>
// imports for all components
import HeaderPrismic from '../components/HeaderPrismic.vue'
import FooterPrismic from '../components/FooterPrismic.vue'

export default {
  name: 'faqs',
  components: {
    HeaderPrismic,
    FooterPrismic
  },
  data () {
    return {
      documentId: '',
      fields: {
        illustration: null,
        pagetitle: null,
        pagedescription: null,
        divcolor: null,
        btnLink: null,
        btnLabel: null,
        mrkQuestion: null,
        lblShowMore: null,
        lblShowLess: null
      },
      metaTags:{
				title: '',
				description: '',
				image: '',
				url: '',
				site_name: '',
				twitter_handle: '',
				twitter_image: '',
				twiter_card: 'summary'
			},
      mainView: {},
      tabletView: {},
      mobileView: {},
      slices: []
    }
  },
  methods: {
    getContent () {
      this.$prismic.client.getSingle('faqs')
        .then((response) => {
          this.fields.illustration = response.data.hero_image
          this.mainView = response.data.hero_image
          this.tabletView = response.data.hero_image.tablet
          this.mobileView = response.data.hero_image.phone
          this.fields.pagetitle = response.data.page_title
          this.fields.pagedescription = response.data.page_description
          this.fields.divcolor = response.data.divider_and_button_color
          this.fields.btnLink = response.data.button_link
          this.fields.btnLabel = response.data.button_label
          this.fields.mrkQuestion = response.data.question_marker
          this.fields.lblShowMore = response.data.show_more
          this.fields.lblShowLess = response.data.show_less

          //Set slices as variable
          this.slices = response.data.body;

          // Set Meta tags
          this.metaTags.title = (response.data.seo_page_title) ? response.data.seo_page_title[0].text : '';
          this.metaTags.description = (response.data.seo_description) ? response.data.seo_description[0].text : '';
          this.metaTags.image = (response.data.meta_image.url) ? response.data.meta_image.url : '';
          this.metaTags.url = (response.data.meta_url) ? response.data.meta_url.link_type : '';
          this.metaTags.site_name = (response.data.meta_site_name) ? response.data.meta_site_name[0].text : '';
          this.metaTags.twitter_handle = (response.data.twitter_handle) ? response.data.twitter_handle : '';
          this.metaTags.twitter_image = (response.data.twitter_image) ? response.data.twitter_image.url : '';
        })
    }
  },
  created () {
    this.getContent();
  }
}
</script>

<style>
.FAQs .small-cta {
  margin-bottom: 100px!important;
}
</style>
