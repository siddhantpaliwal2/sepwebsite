<template>
  <section :class="page">
    <!-- Vue tag to add header component -->
    <header-prismic/>
    <div>
      Actives
    </div>
    <footer-prismic/>
  </section>
</template>
<script>
// imports for all components
import HeaderPrismic from '../components/HeaderPrismic.vue'
import FooterPrismic from '../components/FooterPrismic.vue'


export default {
  name: 'page',
  components: {
    HeaderPrismic,
    FooterPrismic
  },
  data () {
    return {

    }
  },
}
</script>
<style>
</style>
