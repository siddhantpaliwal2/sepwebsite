<template>
	<section class="city" >

		<!-- Vue tag to add header component -->
		<header-prismic/>
		<div>Executives.vue
		</div>
        <footer-prismic/>
	</section>
</template>

<script>
// imports for all components
import HeaderPrismic from '../components/HeaderPrismic.vue'
import FooterPrismic from '../components/FooterPrismic.vue'

export default {
    name: 'city',
    components: {
        HeaderPrismic,
        FooterPrismic
    },
    data () {
        return {
			documentId: '',
			fields: {
				image: null,
				pagetitle: null,
				pagedescription: null,
				divcolor: null,
				btnLink: null,
				btnLabel: null
			},
			metaTags:{
				title: '',
				description: '',
				image: '',
				url: '',
				site_name: '',
				twitter_handle: '',
				twitter_image: '',
				twiter_card: 'summary'
			},
			mainView: {},
			tabletView: {},
			mobileView: {},
			slices: [],
			building: []
        }
    },
    methods: {
        getContent (uid) {
        //Query to get post content
        this.$prismic.client.getByUID('city', uid)
            .then((response) => {
            if (response) {
				this.documentId = response.id
                this.fields.image = response.data.hero_image
                this.mainView = response.data.hero_image
                this.tabletView = response.data.hero_image.tablet
                this.mobileView = response.data.hero_image.phone
                this.fields.pagetitle = response.data.page_title
                this.fields.pagedescription = response.data.page_description
                this.fields.divcolor = response.data.divider_and_button_color
                this.fields.btnLink = response.data.button_link
                this.fields.btnLabel = response.data.button_label

                //Set slices as variable
                this.slices = response.data.body
                this.building = response.data.body.filter(function(slice) {
                  if(slice.slice_type == 'building') {
                    return slice.items;
                  }
                });
                // Set Meta tags
                this.metaTags.title = (response.data.seo_page_title) ? response.data.seo_page_title[0].text : '';
                this.metaTags.description = (response.data.seo_description) ? response.data.seo_description[0].text : '';
                this.metaTags.image = (response.data.meta_image.url) ? response.data.meta_image.url : '';
                this.metaTags.url = (response.data.meta_url) ? response.data.meta_url.link_type : '';
                this.metaTags.site_name = (response.data.meta_site_name) ? response.data.meta_site_name[0].text : '';
                this.metaTags.twitter_handle = (response.data.twitter_handle) ? response.data.twitter_handle : '';
                this.metaTags.twitter_image = (response.data.twitter_image) ? response.data.twitter_image.url : '';
            }
            else {
                //returns error page
                this.$router.push({ name: 'not-found' })
            }
            })
        }
    },
    created () {
		this.getContent(this.$route.params.uid)
    },
    beforeRouteUpdate (to, from, next) {
        this.getContent(to.params.uid)
        next()
    }
}
</script>
<style>
.city .map-outer {
	position: fixed;
    top: 0;
    left: auto;
    height: 100%;
    width: 50%;
    right: 0;
}
.city .building-card {
    padding-right: 25px;
	-webkit-box-pack: center;
	-webkit-justify-content: center;
	-ms-flex-pack: center;
	justify-content: center;
}
.city .building-cms .building-card .content-wrap {
    padding: 0 5px;
	max-width: 235px;
    margin: 0 auto;
}
@media (min-width: 1199px) {
    .city .building-cms:not(.build-page)  .left-content  .left-wrapper {
        max-width: 525px;
        margin: 0 0 0 auto;
    }
}
@media (min-width: 768px) {
	.city .map-outer img {
		height: 100%;
		width: 100%;
	}
	.city .building-cms:not(.build-page)  .left-content  .left-wrapper {
		padding-top: 110px;
		padding-bottom: 65px;
	}
	.city .map-outer .google-map {
		height: 100%;
	}
}
@media screen and (max-width: 1199px) and (min-width: 1080px) {
	.city .building-cms:not(.build-page)  .left-content  .left-wrapper {
		max-width: 510px;
		margin: 0 0 0 auto;
	}
}
@media (max-width: 767px) {
	.city .map-outer {
		position: relative;
		height: 500px;
		width: 100%;
		z-index: 9;
		overflow-x: scroll;
	}
	.google-map {
	    height: 100%;
	}
	.city .building-cms:not(.build-page)  .left-content  .left-wrapper {
		padding-top: 65px;
		padding-bottom: 0;
	}

}
</style>
