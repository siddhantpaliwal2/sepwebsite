<template>
  <section class="">
    <!-- Vue tag to add header component -->
    <header-prismic/>
    <div>
      Bruintank.vue
    </div>
    <footer-prismic/>
  </section>
</template>

<script>
// imports for all components
import HeaderPrismic from '../components/HeaderPrismic.vue'
import FooterPrismic from '../components/FooterPrismic.vue'
import { Carousel, Slide } from 'vue-carousel';

export default {
  name: 'building',
  components: {
    HeaderPrismic,
    FooterPrismic,
    Carousel,
    Slide
  },
  data () {
    return {
      documentId: '',
      fields: {
        image: null,
        building: null,
        imgNeighbourhood: null,
        lblNeighbourhood: null,
        buildingDescriptionShort: null,
        imgApartments: null,
        intApartments: null,
        lbdApartments: null,
        imgBedrooms: null,
        intBedrooms: null,
        lblBedrooms: null,
        imgTrain: null,
        lblTrain: null,
        lbl2Train: null,
        buildingDescription: null,
        /* geoBuilding:  {
          latitude: null,
          longitude: null
        }, */
        buildingAddress: null
      },
      metaTags:{
				title: '',
				description: '',
				image: '',
				url: '',
				site_name: '',
				twitter_handle: '',
				twitter_image: '',
				twiter_card: 'summary'
			},
      mainView: {},
      tabletView: {},
      mobileView: {},
      heroImageSlider: [],
      slices: []
    }
  },
  methods: {
    getContent (uid) {
      //Query to get post content
      this.$prismic.client.getByUID('explore_building', uid)
        .then((response) => {
          if (response) {
            this.documentId = response.id
            this.fields.image = response.data.hero_image
            this.mainView = response.data.hero_image
            this.tabletView = response.data.hero_image.tablet
            this.mobileView = response.data.hero_image.phone
            this.heroImageSlider = response.data.heroimageslider
            this.fields.building = response.data.building_name
            this.fields.imgNeighbourhood = response.data.icon
            this.fields.lblNeighbourhood = response.data.neighbourhood_name
            this.fields.buildingDescriptionShort = response.data.short_building_description
            this.fields.imgApartments = response.data.apartments_image
            this.fields.intApartments = response.data.apartments_number
            this.fields.lbdApartments = response.data.apartments_label
            this.fields.imgBedrooms = response.data.bedrooms_image
            this.fields.intBedrooms = response.data.bedrooms_number
            this.fields.lblBedrooms = response.data.bedrooms_label
            this.fields.imgTrain = response.data.train_image
            this.fields.lblTrain = response.data.train_stop_name
            this.fields.lbl2Train = response.data.train_distrance
            this.fields.buildingDescription = response.data.building_description
            this.fields.buildingAddress = response.data.building_address
            //this.fields.geoBuilding = response.data.building_location

            //Set slices as variable
            this.slices = [];
            response.data.body.forEach((val)=>{
                if(val.slice_type === 'rooms') {
                    val.building_name = this.$route.params.uid
                }
                this.slices.push(val)
            });
            // Set Meta tags
            this.metaTags.title = (response.data.seo_page_title) ? response.data.seo_page_title[0].text : '';
            this.metaTags.description = (response.data.seo_description) ? response.data.seo_description[0].text : '';
            this.metaTags.image = (response.data.meta_image.url) ? response.data.meta_image.url : '';
            this.metaTags.url = (response.data.meta_url) ? response.data.meta_url.link_type : '';
            this.metaTags.site_name = (response.data.meta_site_name) ? response.data.meta_site_name[0].text : '';
            this.metaTags.twitter_handle = (response.data.twitter_handle) ? response.data.twitter_handle : '';
            this.metaTags.twitter_image = (response.data.twitter_image) ? response.data.twitter_image.url : '';
          }
          else {
            //returns error page
            this.$router.push({ name: 'not-found' })
          }
        })
    }
  },
  created () {
    this.getContent(this.$route.params.uid)
  },
  beforeRouteUpdate (to, from, next) {
    this.getContent(to.params.uid)
    next()
  }
}
</script>
<style>
.building .build-page .building-card {
    padding-top: 30px;
    padding-right: 0;
}
.building .image-gallery.content-section {
  margin-bottom: 50px;
}
.building  .build-page {
  margin-bottom: 50px;
  z-index: 3;
}
/* .building  */
.building .image-gallery.content-section .gallery-item.galley-item-avatar .title > :first-child {
  font-size: 11px;
  font-weight: 600;
}
.building .room-wrapper .room-detail .price > :first-child {
  font-size: 18px;
  font-weight: 600;
}
.building .galley-custom-avatar {
  margin-left: -5px;
  margin-right: -5px;
}
/* Slider Bottom */
.building .building-slider .building-slider-content .build-shortdesc {
  display: none;
}
.building .building-slider .building-slider-content {
  margin-top: -100px;
  background-color: rgba(244, 244, 245, 0.9);
  z-index: 99;
  position: relative;
  padding: 20px 70px 35px 70px;
}
.building .building-slider .building-title > :first-child {
	margin-bottom: 10px;
}
.building .building-slider .nb-main .nb-label {
	display: inline-block;
    vertical-align: middle;
}
.building .building-slider .nb-main .nb-label  > :first-child {
	margin-bottom: 0;
}
.building .building-slider .build-shortdesc > :first-child {
	margin-bottom: 0;
    margin-top: 50px;
}
.building .building-slider .icons-details p {
	margin-bottom: 0;
	margin-right: 5px;
}
.building .building-slider .icons-details .icon ,
.building .building-slider .icons-details .desc {
	display: -webkit-box;
	display: -webkit-flex;
	display: -ms-flexbox;
	display: flex;
	-webkit-box-align: center;
	-webkit-align-items: center;
	-ms-flex-align: center;
	align-items: center;
}
.building .building-slider .icons-details .icon-3 .desc {
	display: block;
}
.building .building-slider .icons-details .desc {
	margin-left: 10px;
}
.building .building-slider .icons-details  {
	margin-top: 25px;
}
.building .building-slider .build-desc p {
	margin-bottom: 0;
    margin-top: 30px;
}
.building .building-slider .address {
    margin-top: 25px;
}
.building .building-slider .address p ,
.building .building-slider p.location {
	margin-bottom: 0;
}
.building .building-slider .icons-details .icon:nth-child(n+5) {
	margin-top: 15px;
}
/* gallery images */
.building .text-slice-cms .image-block {
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
}
.building-slider .slider-img img {
  width: 100%;
}
/* embeded video */
.building .embedslice-cms .eb-wrap {
  text-align: center;
}
/*building page */
.building .build-page .building-card .card-main {
    -ms-flex: 0 0 25%;
    -webkit-box-flex: 0;
    flex: 0 0 25%;
    max-width: 25%;
    margin-bottom: 15px;
    padding-right: 15px;
    padding-left: 15px;
}
.building .building-slider .slider-items .slider-item {
  position: relative;
  display: table-cell;
}
.building .building-slider .slider-items {
    width: 100%;
    height: 100%;
    overflow: hidden;
    display: table;
}
.building .building-slider .slider-item .slider-img {
    overflow: hidden;
    width: 100%;
    display: block;
}
.building .building-slider .slider-indicators {
    display: none;
}
.building .building-slider .VueCarousel-navigation-button {
    top: 50%;
    -webkit-transform: translateY(-50%);
    -moz-transform: translateY(-50%);
    -o-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    background-color: #72bf44!important;
    height: 50px;
    border-radius: .3125rem;
    box-shadow: 0 2px 6px 0 rgba(0,0,0,.4);
    padding: 0;
}
.building .building-slider .VueCarousel-navigation-button.VueCarousel-navigation-prev {
    left: 15px;
    right: auto;
}
.building .building-slider .VueCarousel-navigation-button.VueCarousel-navigation-next {
    right: 15px;
    left: auto;
}
.building .building-slider .VueCarousel-navigation-button .fa {
   color: rgba(255,255,255,1);

}
.building .building-slider .VueCarousel-navigation-button.VueCarousel-navigation-prev, .building .building-slider .VueCarousel-navigation-button.VueCarousel-navigation-next {
	padding: 0px 18px!important;
}
.VueCarousel-pagination {
	position: relative;
    top: -120px;
}
@media(max-width:1199px) {
  /* modal height */
  .embed-responsive .embed-responsive-item, .embed-responsive iframe {
    position: relative;
    height: 550px;
  }
  .embed-responsive-16by9::before {
    padding-top: 0;
  }
}
@media(max-width:991px) {
	.building .building-slider .building-slider-content {
		padding: 20px 40px 35px 40px;
	}
  .building .build-page .building-card .card-main {
    -ms-flex: 0 0 33.333333%;
    -webkit-box-flex: 0;
    flex: 0 0 33.333333%;
    max-width: 33.333333%;
  }
   .embed-responsive .embed-responsive-item, .embed-responsive iframe {
    height: 475px;
  }
}
@media(max-width:767px) {
  .VueCarousel-navigation-button.VueCarousel-navigation-next, .VueCarousel-navigation-button.VueCarousel-navigation-prev {
    display: none;
  }
	.building .building-slider .icons-details .icon:nth-child(n+3) {
		margin-top: 15px;
	}
  .embedslice-cms iframe {
    width: 400px;
    height: 400px;
  }
  .building .building-slider .icons-details .icon .icon-wrap  {
    width: 35%;
    text-align: center;
  }
  .building .building-slider .icons-details .desc {
    width: 85%;
  }
  .building .build-page .building-card .card-main {
    -ms-flex: 0 0 50%;
    -webkit-box-flex: 0;
    flex: 0 0 50%;
    max-width: 50%;
  }
}
@media(min-width:481px) and (max-width:575px) {
   .building .building-slider .icons-details .icon .icon-wrap  {
    width: 22%;
  }
  .building .building-slider .icons-details .desc {
    width: 78%;
  }
}
@media(max-width:575px) {
	.building .building-slider .icons-details .icon:nth-child(n+2) {
		margin-top: 15px;
	}
  .embedslice-cms iframe {
    width: 290px;
    height: 330px;
  }
  .building .build-page .building-card .card-main {
    -ms-flex: 0 0 100%;
    -webkit-box-flex: 0;
    flex: 0 0 100%;
    max-width: 100%;
  }
  .embed-responsive .embed-responsive-item, .embed-responsive iframe {
    height: 450px;
  }
  .building-cms .building-card .content-wrap {
    max-width: 225px;
    margin-left: auto;
    margin-right: auto;
  }
    .building .image-gallery.content-section .gallery-item {
        padding-bottom: 20px;
    }
}

</style>
