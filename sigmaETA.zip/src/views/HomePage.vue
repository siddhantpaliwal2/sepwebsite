<template>

  <section class="homepage">

    <header-prismic/>
    <section class="slider-cms">

    </section>
    <footer-prismic/>
  </section>
</template>

<script>
// imports for all components
import HeaderPrismic from '../components/HeaderPrismic.vue'
import FooterPrismic from '../components/FooterPrismic.vue'

export default {
  name: 'home-page',
  components: {
    HeaderPrismic,
    FooterPrismic
  },
  data () {
    return {
    }
  }
}
</script>

<style>
.slider-cms {
margin-top: 100px;
}
</style>
