<template>
  <div id="app" class="row">
    <router-view/>
  </div>
</template>

<script>
//import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

export default {
  name: 'App'
}
</script>

<style>
@import "./assets/css/common.css";
/* @import url(https://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic); */
</style>
